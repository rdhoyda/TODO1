// import { useReducer } from "react";
// import CreatePost from "./CreatePost";
// import UserBar from "./Userbar";
// import PostsProvider from "./PostsProvider";

// function App() {
//   function userReducer(state, action) {
//     switch (action.type) {
//       case "LOGIN":
//       case "REGISTER":
//         return action.username;
//       case "LOGOUT":
//         return "";
//       default:
//         return state;
//     }
//   }

//   const [user, dispatchUser] = useReducer(userReducer, "");

//   function postReducer(state, action) {
//     switch (action.type) {
//       case "CREATE_POST":
//         const newPost = {
//           title: action.title,
//           content: action.content,
//           author: action.author,
//         };

//         // Return a new array with the new post appended to the existing state
//         return [newPost, ...state];
//       default:
//         return state;
//     }
//   }

//   const [posts, dispatchPost] = useReducer(postReducer, []); // Initialize with an empty array

//   const handleAddPost = (newPost) => {
//     dispatchPost({ type: "CREATE_POST", ...newPost });
//   };

//   return (
//     <div>
//       <UserBar user={user} dispatchUser={dispatchUser} />
//       <CreatePost user={user} handleAddPost={handleAddPost} />
//       <PostsProvider posts={posts} />
//     </div>
//   );
// }

// export default App;
















//************************************************************************************************************************* */

// import { useState } from "react";
// import CreatePost from "./CreatePost";
// import UserBar from "./Userbar";
// import PostsProvider from "./PostsProvider";

// function App(){

// const [user, setUser] = useState("");
// const initialPosts= [
//   {title: "Concepts of Physics", description: "Laws of Motion", author:"Rohan Dhoyda"},
//   {title: "Applied Mathematics", description: "Concepts of Discrete Mathematics", author:"Rohan Dhoyda"}
// ]
// const [posts, setPosts] = useState(initialPosts);
// const handleAddPost = (newPost) => {
//   setPosts([newPost,...posts]);
// };
// return (
//   <div>
//   <UserBar user={user} setUser={setUser} />
//   <CreatePost user={user} handleAddPost={handleAddPost}/>
//   <PostsProvider posts={posts} />
//   </div>
//   )

//   }
//   export default App;


// import { useState, useReducer } from "react";
// import CreatePost from "./CreatePost";
// import UserBar from "./Userbar";
// import {PostsProvider} from "./PostsContext";

// function App() {
//   // User state using useState
//   const [user, setUser] = useState("");

//   function userReducer(state, action) {
//     switch (action.type) {
//       case "LOGIN":
//       case "REGISTER":
//         return action.username;
//       case "LOGOUT":
//         return "";
//       default:
//         return state;
//     }
//   }

//   const [globalUser, dispatchUser] = useReducer(userReducer, ""); // Global user state

//   function postReducer(state, action) {
//     switch (action.type) {
//       case "CREATE_POST":
//         const newPost = {
//           title: action.title,
//           content: action.content,
//           author: action.author,
//         };

//         // Return a new array with the new post appended to the existing state
//         return [newPost, ...state];
//       default:
//         return state;
//     }
//   }

//   const [posts, dispatchPost] = useReducer(postReducer, []); // Initialize with an empty array

//   const handleAddPost = (newPost) => {
//     dispatchPost({ type: "CREATE_POST", ...newPost });
//   };

//   return (
//     <div>
//       <UserBar user={user} dispatchUser={dispatchUser} />
//       <CreatePost user={user} handleAddPost={handleAddPost} />
//       <PostsProvider posts={posts} />
//     </div>
//   );
// }

// export default App;



import React, { useState, useReducer } from "react";
import CreatePost from "./CreatePost";
import UserBar from "./Userbar";
import {PostsProvider} from "./PostsProvider";

function App() {

  const initialPosts = [
      {
        title: "React Hooks",
        content: "The great thing since sliced bread!",
        author: "Daniel Bugl"
      },
      {
        title: "USing React Fragment",
        content: "Keeping the DOM tree clean",
        author: "Daniel Bugl"
      },
      {
        title: "Component reuasability",
        content: "Make your component reusable",
        author: "Daniel Bugl"
      }
    ]
    
    const [createPostVisible, setCreatePostVisible] = useState(false);
  
    function userReducer(state, action) {
      switch (action.type) {
        case "LOGIN":
          setCreatePostVisible(true); // Show the create posts component
          return action.username;
        case "REGISTER":
          setCreatePostVisible(true); // Show the create posts component
          return action.username;
        case "LOGOUT":
          setCreatePostVisible(false); // Hide the create posts component
          return null;
        default:
          return state;
      }
    }
  
  const [user, dispatchUser] = useReducer(userReducer, "");
    
  
    function postReducer(state, action) {
      switch (action.type) {
        case "CREATE_POST":
          const newPost = {
            title: action.title,
            content: action.content,
            author: user, // Use the current user as the author
            complete: false,
            dateCreated: new Date().toISOString(),
            dateCompleted: null,
          };
          return [newPost, ...state];
  
        case "TOGGLE_POST":
          const updatedPosts = state.map((post) => {
            if (post.title === action.title) {
              // Toggle the 'complete' field
              post.complete = !post.complete;
              // Set the 'dateCompleted' field to the current date or null
              post.dateCompleted = post.complete ? new Date().toISOString() : null;
            }
            return post;
          });
          return updatedPosts;
  
        case "DELETE_POST":
          return state.filter((post) => post.title !== action.title);
  
        default:
          return state;
      }
    }
  
  const [posts, dispatchPost] = useReducer(postReducer, initialPosts);
    const handleAddPost = (newPost) => {
      dispatchPost({ type: "CREATE_POST", ...newPost });
    };
  
    return (
      <div>
        <UserBar user={user} dispatchUser={dispatchUser} />
        {user &&
          <CreatePost user={user} handleAddPost={handleAddPost} />
        }
        <PostsProvider posts={posts} dispatchPost={dispatchPost} />
      </div>
    );
  }
  
  
  export default App;